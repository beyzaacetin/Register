package OopIntro_1.Odev4_1;

import java.rmi.RemoteException;

public interface IUserService {
    void add(User user) throws NumberFormatException, RemoteException;
    void update(User user) throws NumberFormatException, RemoteException;
    void delete(User user) throws NumberFormatException, RemoteException;
}
