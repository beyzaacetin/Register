package OopIntro_1.Odev4_1;

import java.rmi.RemoteException;

public interface IPersonCheckService {
    boolean chechIfRealPerson(User user) throws NumberFormatException, RemoteException;
}
