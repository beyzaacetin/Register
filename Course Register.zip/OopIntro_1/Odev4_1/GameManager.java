package OopIntro_1.Odev4_1;

public class GameManager implements IGameService{
    @Override
    public void add(Games games) {
        System.out.println(games.getGameName()+" OYUNU EKLENDİ!");
    }


    @Override
    public void update(Games games) {
        System.out.println(games.getGameName()+" OYUNU GÜNCELLENDİ!");
    }

    @Override
    public void delete(Games games) {
        System.out.println(games.getGameName()+" OYUNU SİLİNDİ!");
    }
}
