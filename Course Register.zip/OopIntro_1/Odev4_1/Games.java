package OopIntro_1.Odev4_1;

public class Games {
    private String gameName;
    private double gamePrice;

    public Games(){

    }
    public Games(String gameName, double gamePrice) {
        this.gameName = gameName;
        this.gamePrice = gamePrice;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public double getGamePrice() {
        return gamePrice;
    }

    public void setGamePrice(double gamePrice) {
        this.gamePrice = gamePrice;
    }
}
