package OopIntro_1.Odev4_1;

import java.rmi.RemoteException;

public class UserManager implements IUserService{

    private IGameService[] loggings;
    private UserManager(IGameService[] loggings){
        this.loggings=loggings;
    }


    public void add(User user){
        System.out.println("Kullanıcı Eklendi: " + user.getFirstName()+user.getLastName() + user.getTcNo());

    }

    @Override
    public void update(User user) throws NumberFormatException, RemoteException {
        System.out.println("Kullanıcı Güncellendi: " + user.getFirstName()+user.getLastName() + user.getTcNo());
    }

    @Override
    public void delete(User user) throws NumberFormatException, RemoteException {
        System.out.println("Kullanıcı Silindi: " + user.getFirstName()+user.getLastName() + user.getTcNo());
    }
}
