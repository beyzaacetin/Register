package OopIntro_1.Odev4_1;

import java.rmi.RemoteException;

public class Main {
    public static void main(String[] args) throws  NumberFormatException, RemoteException {

       User user = new User(190201012,"Beyza","Çetin",2001);

       Games games = new Games("Adventure",100);

       Campaign campaign = new Campaign("New Year Sale ",10);

       GameManager gameManager = new GameManager();
       gameManager.add(games);

       SaleManager saleManager = new SaleManager();
       saleManager.gameSales(user,games,campaign);

    }
}
