package OopIntro_1.Odev4_1;

import OopIntro_1.Odev3_1.User;

public interface IGameService {
    void add(Games games);
    void update(Games games);
    void  delete(Games games);
}
