package OopIntro_1.Odev4_1;

public interface ICampaignService {
    void add(Campaign campaing);
    void delete(Campaign campaing);
    void  update(Campaign campaign);
}
