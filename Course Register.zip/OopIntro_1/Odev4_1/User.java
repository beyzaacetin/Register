package OopIntro_1.Odev4_1;

public class User  {
    private int tcNo;
    private  String firstName;
    private String lastName;
    private int year;

    public User(){

    }

    public User(int tcNo, String firstName, String lastName, int year) {
        this.tcNo = tcNo;
        this.firstName = firstName;
        this.lastName = lastName;
        this.year = year;
    }

    public int getTcNo() {
        return tcNo;
    }

    public void setTcNo(int tcNo) {
        this.tcNo = tcNo;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }


}
