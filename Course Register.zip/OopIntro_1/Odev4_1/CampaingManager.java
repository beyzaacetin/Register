package OopIntro_1.Odev4_1;

public class CampaingManager implements ICampaignService {
    @Override
    public void add(Campaign campaing) {

    }

    @Override
    public void delete(Campaign campaing) {

    }

    @Override
    public void update(Campaign campaign) {

    }
}
