package OopIntro_1.Odev4_1;

public class SaleManager {
    public void gameSales(User user,Games games,Campaign campaign){
        double discountPrice;
        discountPrice = (games.getGamePrice()- ((games.getGamePrice()) * campaign.getRateOfDiscount())/100);
        System.out.println(games.getGameName() + " indirimli = " + " " + discountPrice);
    }
}
