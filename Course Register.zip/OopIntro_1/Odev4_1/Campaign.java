package OopIntro_1.Odev4_1;

public class Campaign {
    private String discountName;
    private double rateOfDiscount;

    public Campaign(){}

    public Campaign(String discountName, double rateOfDiscount) {
        this.discountName = discountName;
        this.rateOfDiscount = rateOfDiscount;
    }

    public String getDiscountName() {
        return discountName;
    }

    public void setDiscountName(String discountName) {
        this.discountName = discountName;
    }

    public double getRateOfDiscount() {
        return rateOfDiscount;
    }

    public void setRateOfDiscount(double rateOfDiscount) {
        this.rateOfDiscount = rateOfDiscount;
    }
}
