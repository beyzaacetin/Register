package OopIntro_1.Odev4_2CoffeShop.Concrete;

import OopIntro_1.Odev4_2CoffeShop.Abstract.BaseCustomerManager;
import OopIntro_1.Odev4_2CoffeShop.Abstract.ICustomerService;
import OopIntro_1.Odev4_2CoffeShop.Entities.Customer;

public class NeroCustomerManager extends BaseCustomerManager {

}
