package OopIntro_1.AbstractClass;

public abstract class BaseDataBaseManager {
    public abstract void getData();
}
