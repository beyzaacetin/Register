package OopIntro_1.AbstractClass;

public class Main {
    public static void main(String[] args){
        CustomerManager customerManager = new CustomerManager();
        customerManager.dataBaseManager = new OracleDataBaseManagre();
        customerManager.dataBaseManager = new SqlServiceDatabaseManageri();
        customerManager.getCustomers();

    }
}
