package OopIntro_1.AbstractClass;

public class CustomerManager {

    BaseDataBaseManager dataBaseManager;

    public void getCustomers(){
        dataBaseManager.getData();
    }
}
