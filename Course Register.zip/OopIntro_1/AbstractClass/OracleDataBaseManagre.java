package OopIntro_1.AbstractClass;

public class OracleDataBaseManagre extends  BaseDataBaseManager{
    @Override
    public void getData() {
        System.out.println("Veri getirildi : Oracle");
    }
}
