package OopIntro_1.AbstractClass;

public class SqlServiceDatabaseManageri extends BaseDataBaseManager{
    @Override
    public void getData() {
        System.out.println("Veri girildi : SQL servis");
    }
}
