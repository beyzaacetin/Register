package OopIntro_1.Interfaces;

public interface Logger {
    void log(String message);
}
