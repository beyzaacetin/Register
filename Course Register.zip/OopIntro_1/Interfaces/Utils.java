package OopIntro_1.Interfaces;

public class Utils {

    public static void  runLogger(Logger[] loggers, String message){
//methodu static yaptığımda diğer sınıfımda newleme ihtiyacı duymuyoruz
// ama her zaman numu kullanamyız
//normal public void olarak bir method yazdığımızda diğer class da onu newleyerek önce çağırmalıyız daha sonrasında kullanabiliriz.
//Utils utils = new Utils();
//utils.runLogger(loggers, customer.getFirstName());
        for (Logger logger : loggers){
            logger.log(message);
        }}

}
