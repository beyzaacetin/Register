package OopIntro_1.Interfaces;

public class DataBaseLogger2 implements  Logger{
    @Override
    public void log(String message) {
        System.out.println("Database loglandı: " + message);
    }
}
