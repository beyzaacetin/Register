package OopIntro_1.Interfaces;


import OopIntro_1.Inheritance_2.SmsLogger;

public class Main {
    public static void main(String[] args){
        Logger[] loggers = {new SmsLogger(), new EmailLogger(), new FileLogger()};
        CustomerManager2 customerManager = new CustomerManager2(loggers);

        Customer engin = new Customer(1,"Engin","Demiroğ");

        customerManager.add(engin);
        //customerManager.delete(engin);

    }
}
