package OopIntro_1.Interfaces;

public class CustomerManager2 {
    //sadece müşteriyi etkileyen kaynaklar yazılır
    //loosly - tighly coupled

    private Logger[] loggers;
    public CustomerManager2(Logger[] loggers) {
        this.loggers = loggers;
    }


    public void add(Customer customer){

        System.out.println("Müşteri eklendi: " + customer.getFirstName());
        //logger.log(customer.getFirstName());

        //DataBaseLogger2 logger = new DataBaseLogger2();
        //this.logger.log(customer.getFirstName() );
        /*for (Logger logger : loggers){
            logger.log(customer.getFirstName());
        }
         */
        /*Utils utils = new Utils();
        utils.runLogger(loggers, customer.getFirstName());
         */
        Utils.runLogger(loggers, customer.getFirstName());//static yaptığımız için newlememize gerek kalmadı
    }

    public void  delete(Customer customer){
        System.out.println("Müşteri silindi: " + customer.getFirstName());
        //DataBaseLogger2 logger = new DataBaseLogger2();
        //this.logger.log(customer.getFirstName() );
        for (Logger logger : loggers){
            logger.log(customer.getFirstName());
        }
    }

    //birden fazla logglama sistemini barındırma


}
