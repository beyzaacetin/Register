package OopIntro_1.Interfaces;

public class FileLogger implements  Logger{
    @Override
    public void log(String message) {
        System.out.println("Dosyaya Loglandı: " + message);
    }
}
