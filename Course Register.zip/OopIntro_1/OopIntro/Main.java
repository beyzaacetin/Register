package OopIntro_1.OopIntro;

public class Main {
    public static void main(String[] args){
        //String[] products = {"Lenovo V14","Lenovo V15","Hp 5"};
        Product product1 = new Product(1,"Lenovo V14",1500,"16 GB Ram",10); //referans oluşturma, intance
        Product product2 = new Product(1,"Lenovo V15",1600,"16 GB Ram",20); //referans oluşturma, intance
        product2.setId(1);
        product2.setName("Lenova V15");
        product2.setUnitPrice(1600);
        product2.setDetail("16GB Ram");
        product2.setDiscount(20);
        System.out.println(product2.getUnitPriceAfterDiscount());




        Product product3 = new Product(1,"Hp 5",1700,"32 GB Ram",15); //referans oluşturma, intance

        Product[] products = {product1,product2,product3 };

        for(Product product : products){
            System.out.println(product.getName());
            System.out.println((product.getUnitPrice()));
        }

        System.out.println(products.length);

        Category category1 = new Category();
        category1.setId(1);
        category1.setName("İçecek");

        Category category2 = new Category();
        category2.setId(2);
        category2.setName("Yiyecek ");

        System.out.println(category1.getName());
        System.out.println(category2.getName());
/*
        ProductManager productManager = new ProductManager();
        productManager.addToCart(product1);
        productManager.addToCart(product2);

 */


    }
}
