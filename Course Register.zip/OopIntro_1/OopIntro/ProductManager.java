package OopIntro_1.OopIntro;

import OopIntro_1.OopIntro.Product;

public class ProductManager {
    public  void addToCart(Product product){
        System.out.println("Sepete " + product.getName() + " eklendi");

    }
}
