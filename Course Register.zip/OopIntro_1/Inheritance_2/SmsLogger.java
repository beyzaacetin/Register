package OopIntro_1.Inheritance_2;

import OopIntro_1.Interfaces.Logger;

public class SmsLogger implements Logger {
    @Override
    public void log(String message) {
        System.out.println("Sms gönderildi :" + message);
    }//uyarla

}
