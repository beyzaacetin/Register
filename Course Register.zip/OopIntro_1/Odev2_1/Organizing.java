package OopIntro_1.Odev2_1;

public class Organizing {
    public void addStudent(Class student){
        System.out.println("Added " + student.id
                + " from class!");
    }

    public  void deleteStudent(Class student){

        System.out.println("Deleted " + student.department
                + " from class!");
    }
}
