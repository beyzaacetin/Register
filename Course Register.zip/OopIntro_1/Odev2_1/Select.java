package OopIntro_1.Odev2_1;

public class Select {
    int id;
    String name;
}
