package OopIntro_1.Odev2_1;

public class Main {
    public static void main(String[] args){
        Class class1 = new Class(14,"Emma","CS",3.52);
        Class class2 = new Class(15,"Thomas","EEE",2.87);
        Class class3 = new Class(16,"Chuck","IE",3);

        Class[] classes = {class1,class2,class3};

        for (Class student : classes){
            System.out.println(student.id);
            System.out.println(student.department);
        }

        Select select_1 = new Select();
        select_1.id = 1;
        select_1.name = "Computer";

        Select select_2 = new Select();
        select_2.id =2;
        select_2.name="Electronic";

        Organizing organizing = new Organizing();
        organizing.addStudent(class1);
        organizing.deleteStudent(class2);

    }
}
