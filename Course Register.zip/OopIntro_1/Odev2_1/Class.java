package OopIntro_1.Odev2_1;

public class Class {
    int id;
    String name;
    String department;
    double average;

    public Class(int id, String name, String department,
                 double average){
        this.id=id;
        this.name=name;
        this.department=department;
        this.average=average;

    }
}
