package OopIntro_1.Inheritance;

public class IndividualCustomer extends Customer{

    String firstName;
    String lastName;
    String nationalIdentity;
}
