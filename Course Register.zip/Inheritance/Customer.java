package OopIntro_1.Inheritance;

public class Customer {
      int id;
      String customerNumber;

}
