package OopIntro_1.Inheritance;

public class CorporateCustomer extends Customer {
    //bir class ne yapabiliyorsa sadece onları yapabilmeli

    String companyName;
    String taxName;
}

