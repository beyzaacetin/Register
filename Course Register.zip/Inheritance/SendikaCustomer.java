package OopIntro_1.Inheritance;

public class SendikaCustomer extends Customer{
    String sendikaBiseyi;
}
