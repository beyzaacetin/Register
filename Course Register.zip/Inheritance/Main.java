package OopIntro_1.Inheritance;

public class Main {

    public  static void main(String[] args){
        Customer customer = new Customer();
        IndividualCustomer engin = new IndividualCustomer();
        engin.customerNumber = "1235";

        CorporateCustomer hepsiBurada = new CorporateCustomer();
        hepsiBurada.companyName="Hepsi Burada";
        hepsiBurada.customerNumber="45789";

        SendikaCustomer abc = new SendikaCustomer();
        abc.customerNumber = "999";

        CustomerManager customerManager = new CustomerManager();
        /*customerManager.add(hepsiBurada);
        customerManager.add(engin);
        customerManager.add(abc);
         */
        Customer[] customers = {engin, hepsiBurada, abc};
        customerManager.addMultiple(customers);

    }
}
