package OopIntro_1.Inheritance_2;

public class CustomerManager {
    public void add(Logger logger){
        //müşteri ekleme kodları
        System.out.println("Müşteri eklendi");
        //DatabaseLogger logger = new DatabaseLogger(); gerek yok
        logger.log();
    }
}
