package OopIntro_1.Inheritance_2;

public class FileLogger extends Logger {
    @Override
    public void log(){//override etme
        System.out.println("Dosya yollandı");

}
}
