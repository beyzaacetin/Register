package OopIntro_1.Inheritance_2;

public class EmailLogger extends  Logger{
    @Override
    public void log(){//override etme
        System.out.println("Email yollandı");

    }

}
