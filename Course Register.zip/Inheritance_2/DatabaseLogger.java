package OopIntro_1.Inheritance_2;

public class DatabaseLogger extends  Logger{
    @Override
    public void log(){//override etme
        System.out.println("Database yollandı");

    }
}
