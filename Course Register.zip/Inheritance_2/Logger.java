package OopIntro_1.Inheritance_2;

public class Logger {
//temel sınıf
    public void log(){
        System.out.println("Ortak konfigürasyon");

    }
}
